﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication12
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string First_name = textBox1.Text.Trim();
            string Last_name = textBox2.Text.Trim();
            string Address = textBox3.Text.Trim();
            decimal Math_Degree = numericUpDown1.Value;
            decimal English_Degree = numericUpDown2.Value;
            decimal IT_Degree = numericUpDown3.Value;
            decimal Total_Grade = Math_Degree + English_Degree + IT_Degree;
            textBox4.Text = Total_Grade.ToString().Trim();
            if (First_name == null || First_name == "" || Last_name == null || Last_name == "" || Address == null || Address == "" || Math_Degree == null || English_Degree == null || IT_Degree == null)
            {
                MessageBox.Show("Please check your data!"); 
            }
            else
            {
                dataGridView1.Rows.Add(First_name,Last_name,Address,Math_Degree,English_Degree,IT_Degree,Total_Grade);
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                numericUpDown1.Value = 0;
                numericUpDown2.Value = 0;
                numericUpDown3.Value = 0;

            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int NumberOfSelectRow = dataGridView1.SelectedRows.Count;
            if (NumberOfSelectRow > 0)
                foreach (DataGridViewRow Row in dataGridView1.SelectedRows)
                {
                    dataGridView1.Rows.RemoveAt(Row.Index);
                }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView1.SelectedCells.Count > 0)
                {
                    textBox1.Text = dataGridView1.SelectedCells[0].Value.ToString();
                    textBox2.Text = dataGridView1.SelectedCells[1].Value.ToString();
                    textBox3.Text = dataGridView1.SelectedCells[2].Value.ToString();
                    numericUpDown1.Value = Convert.ToDecimal(dataGridView1.SelectedCells[3].Value);
                    numericUpDown2.Value = Convert.ToDecimal(dataGridView1.SelectedCells[4].Value);
                    numericUpDown3.Value = Convert.ToDecimal(dataGridView1.SelectedCells[5].Value);
                    textBox4.Text = dataGridView1.SelectedCells[6].Value.ToString();
                }
                else { }
            }
            catch {
                MessageBox.Show("Please select a row first!");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            decimal Math_Degree = numericUpDown1.Value;
            decimal English_Degree = numericUpDown2.Value;
            decimal IT_Degree = numericUpDown3.Value;
            decimal Total_Grade = Math_Degree + English_Degree + IT_Degree;
            textBox4.Text = Total_Grade.ToString();
            foreach (DataGridViewRow Row in dataGridView1.SelectedRows)
            {
                Row.Cells[0].Value = textBox1.Text;
                Row.Cells[1].Value = textBox2.Text;
                Row.Cells[2].Value = textBox3.Text;
                Row.Cells[3].Value = numericUpDown1.Value;
                Row.Cells[4].Value = numericUpDown2.Value;
                Row.Cells[5].Value = numericUpDown3.Value;
                Row.Cells[6].Value = textBox4.Text;
            }
        }
    }
}
